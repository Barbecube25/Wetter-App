package de.barbecube25.wetter;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
